<?php

$dlang = array
(
	'nextpage' => '下一頁',
	'date' => '前,天,昨天,前天,小時,半,分鐘,秒,剛才'
);

?>