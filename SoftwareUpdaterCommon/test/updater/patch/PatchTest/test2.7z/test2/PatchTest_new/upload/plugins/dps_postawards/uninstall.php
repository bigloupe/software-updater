<?php

/*
	[Discuz!] (C)2001-2009 Comsenz Inc. & (C)2009 DPS LuciferSheng
	This is NOT a freeware, use is subject to license terms

	$Id: uninstall.php 21306 2009-11-26 00:56:50Z monkey $
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

echo "<script type=\"text/javascript\" src=\"http://www.7dps.com/stat/stat.php?a=uninstall&u=$boardurl&pn=dps_postawards&v=1.0.0&dz=$version\"></script>";

$finish = TRUE;

?>