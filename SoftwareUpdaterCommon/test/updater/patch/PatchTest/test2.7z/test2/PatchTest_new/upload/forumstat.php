<?php

/*
	[Discuz!] (C)2001-2009 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: ajax.php 17239 2008-12-11 05:12:34Z liuqiang $
*/

define('CURSCRIPT', 'forumstat');
define('NOROBOT', TRUE);

require_once './include/common.inc.php';
showmessage('success');
?>