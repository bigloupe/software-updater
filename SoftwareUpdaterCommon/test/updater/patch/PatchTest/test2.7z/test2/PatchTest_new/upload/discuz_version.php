<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('DISCUZ_VERSION', '7.2');
define('DISCUZ_RELEASE', '20101020');

?>